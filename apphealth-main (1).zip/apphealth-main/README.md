# Siha 
### A healthcare app

Many patients in various communities face difficulties in obtaining timely and appropriate healthcare services. This can result in diagnostic delays, worsening symptoms, and potentially life-threatening conditions. Patients frequently have difficulty locating medical practitioners in their area or locating the appropriate medical facility to address their health concerns

## About Siha
an innovative healthcare app that connects patients with medical practitioners and nearby medical facilities.

This project is a school project.

## Figma Design
https://www.figma.com/file/8RCO829wQ8JhKuLEGVk1Mi/SIha_health_app_?t=wTqvogBWPv66JUTa-0

## Setup
1. Clone repo
2. Navigate to app folder using "cd /app"
3. Install dependencies. Run "flutter pub get"
4. Run app "flutter run" at the root of app directory

### Challenges 
Integrating Firebase. We used the learning and other resources to overcome.

### Resources
https://www.youtube.com/watch?v=LzEbpALmRlc&list=PLgGjX33Qsw-Ha_8ks9im86sLIihimuYrr
https://www.sjinnovation.com/flutter-login-and-registration-using-firebase



