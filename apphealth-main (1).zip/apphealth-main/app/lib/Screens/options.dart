import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class OPtions extends StatefulWidget {
  const OPtions({super.key});

  @override
  State<OPtions> createState() => _OPtionsState();
}

class _OPtionsState extends State<OPtions> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}