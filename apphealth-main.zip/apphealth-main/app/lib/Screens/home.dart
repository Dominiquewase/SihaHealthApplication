import 'package:app/widgets/utils.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  // const Home(User? user, {super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
//       body: Column(
//         children: [
//           Container(
//             height: size.height * 0.2,
//             child: Stack(
//               children: <Widget>[
//                 Container(
//                   height: size.height * .2 - 25,
//                   decoration: BoxDecoration(
//                       color: Colors.teal,
//                       borderRadius: BorderRadius.only(
//                         bottomLeft: Radius.circular(30),
//                         bottomRight: Radius.circular(30),
//                       )),
//                 ),
//                 Container(
//                   padding: EdgeInsets.all(8),
//                   margin: EdgeInsets.fromLTRB(10, 10, 0, 0),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Text(
//                         "Hi James",
//                         style: TextStyle(
//                           color: Colors.white,
//                         ),
//                         textScaleFactor: 2,
//                       ),
//                       CircleAvatar(
//                         backgroundColor: Colors.white.withOpacity(.5),
//                         radius: 30,
//                       )
//                     ],
//                   ),
//                 ),
//                 Positioned(
//                     bottom: 0,
//                     left: 0,
//                     right: 0,
//                     child: Container(
//                       alignment: Alignment.center,
//                       margin: EdgeInsets.symmetric(horizontal: 10),
//                       padding: EdgeInsets.symmetric(horizontal: 10),
//                       height: 45,
//                       decoration: BoxDecoration(
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(25),
//                           boxShadow: [
//                             BoxShadow(
//                               offset: Offset(0, 10),
//                               blurRadius: 50,
//                               color: Colors.teal.withOpacity(.25),
//                             )
//                           ]),
//                       child: Row(
//                         children: <Widget>[
//                           Expanded(
//                             child: TextField(
//                               decoration: InputDecoration(
//                                 hintText: "Search",
//                                 hintStyle: TextStyle(
//                                     color: Colors.teal.withOpacity(.5)),
//                                 enabledBorder: InputBorder.none,
//                                 focusedBorder: InputBorder.none,
//                                 prefixIcon: Icon(
//                                   Icons.search_rounded,
//                                   color: Colors.teal.withOpacity(.5),
//                                 ),
//                               ),
//                             ),
//                           )
//                         ],
//                       ),
//                     ))
//               ],
//             ),
//           ),
//           ListView.builder(
//           scrollDirection: Axis.horizontal,
//           itemCount: 10,
//           itemBuilder: (BuildContext context, int index) {
//             return Container(
//               margin: EdgeInsets.all(8),
//               width: 100,
//               height: 100,
//               decoration: BoxDecoration(
//                 color: Colors.grey,
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               child: Center(
//                 child: Text(
//                   'Item ${index + 1}',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                   ),
//                 ),
//               ),
//     );
//   },
// )

          
//         ],
//       ),


      body: Stack(
        children:<Widget> [
          Container(
            height: size.height*.35,
            decoration: BoxDecoration(
              color: const Color.fromARGB(120, 0, 150, 135).withOpacity(.5),
              
            ),
          ),
          SafeArea(child: 
          Padding(padding: const EdgeInsets.symmetric(horizontal:20, vertical: 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Align(
                alignment: Alignment.topRight,
                child: Container(
                  alignment: Alignment.center,
                  height: 52,
                  width: 52,
                  decoration: const BoxDecoration(
                    color: Color.fromARGB(162, 32, 192, 176),
                    shape: BoxShape.circle
                  ),
                  child:  const Icon(Icons.menu, color: Colors.white,),
                ),
              ),
              Text(
                "Good Morning \nKim",
                style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height:30),
              Container(
                alignment: Alignment.center,
                margin: const EdgeInsets.symmetric(horizontal: 10),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                height: 45,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      offset:const Offset(0, 10),
                      blurRadius: 50,
                      color: Color.fromARGB(255, 15, 15, 15).withOpacity(.25),
                    )
                  ]),
                  child: Row(
                  children: <Widget>[
                    Expanded(
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: "Search",
                          hintStyle: TextStyle(
                              color: Colors.teal.withOpacity(.5)),
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          prefixIcon: Icon(
                            Icons.search_rounded,
                            color: Colors.teal.withOpacity(.5),
                          ),
                        ),
                      ),
                    )
                    ],
                    ),
                    
              ),
              const SizedBox(height: 30,),
              GridView.count(crossAxisCount: 2,
              shrinkWrap: true,
              mainAxisSpacing: 20,
              crossAxisSpacing: 20,
              children: const < Widget>[
                Card(
                  color: Colors.teal,
                        child: Center(
                          child: Text(
                            "Item 1",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ),
                ),
                 Card(
                  color: Color.fromARGB(200, 24, 202, 184),
                        child: Center(
                          child: Icon(Icons.local_hospital, color: Colors.white,size:100),
                          // Text(
                          //   "Item 1",
                          //   style: TextStyle(
                          //     color: Colors.white,
                          //     fontSize: 16,
                          //   ),
                          // ),
                          
                        ),
                ),
                 Card(
                  color: Colors.teal,
                        child: Center(
                          child: Text(
                            "Item 1",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ),
                ),
                 Card(
                  color: Colors.teal,
                        child: Center(
                          child: Text(
                            "Item 1",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ),
                ),

              ],
              ),

              
              ],
          ),)
          )
        ],
      ),

    );
  }
}
